var myDiv = document.getElementById("display");
myDiv.scrollTop = myDiv.scrollHeight;